
import React from "react";

let Button = () => {
  return (<>
    <button>Click Me</button>
  </>)
};

export default Button